<?php
/**
 * Header template for our theme
 *
 * Displays all of the <head> section and <header> content
 *
 * @since easyblue
 */
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">

    <meta name="description" content="<?php bloginfo( 'description' );?>">

    <!-- META per Mobile -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>

    <!-- INIZIO HEADER -->
    <header class="header clearfix">
      <div class="header__top clearfix">
        <a href="<?php echo get_home_url();?>" class="header__logo"><?php bloginfo ('name'); ?></a>
        <ul>
          <li class="header__social"><a href="<?php echo get_theme_mod('link-3', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-3', esc_html__('fa-twitter-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
          <li class="header__social"><a href="<?php echo get_theme_mod('link-2', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-2', esc_html__('fa-facebook-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
          <li class="header__social"><a href="<?php echo get_theme_mod('link-1', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-1', esc_html__('fa-linkedin-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
        </ul>
      </div>


      <div class="header__visual" style="background-image: url(<?php echo get_theme_mod('header-image', get_template_directory_uri() . '/img/header.jpg'); ?>)">
        <div class="header__visual__left">
          <h1 class="header__title"><?php echo get_theme_mod('header-title', esc_html__('IMPRESSIVE TITLE', 'easyblue')); ?></h1>
          <p class="header__subtitle"><?php echo get_theme_mod('header-text', esc_html__('Some impressive words, that can focus your attention on the mean of our mission. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.', 'easyblue')); ?></p>
          <div class="header__call">
            <a class="header__call__link" href="<?php echo get_theme_mod('header-button-url', esc_url ('#')); ?>"><p><?php echo get_theme_mod('header-button-text', esc_html__('CALL TO ACTION', 'easyblue')); ?></p></a>
          </div>
        </div>
      </div>


      <?php /* Main Navigation */
        wp_nav_menu( array(
          'theme_location' => 'header',
          'depth' => 1,
          'container' => false,
          'menu_class' => 'header__menu',
          'fallback_cb'     => 'easyblue_top_bar_menu_cb',
          )
        );
      ?>

    </header>
