<?php
/**
 * Template for displaying the footer
 *
 * Contains the closing of the class=container cards div and class=footer blu div
 *
 * @package easyblue
 */
?>


<!-- FOOTER -->
<footer>
  <div class="footer clearfix">
    <div class="footer__menu clearfix">
      <a href="<?php echo get_home_url();?>" class="footer__menu__theme"><?php bloginfo ('name'); ?></a>

      <?php /* Main Navigation */
        wp_nav_menu( array(
          'theme_location' => 'footer',
          'depth' => 1,
          'container' => false,
          'menu_class' => 'footer__ul',
		  'fallback_cb'     => 'easyblue_top_bar_menu_cb',
          )
        );
      ?>

    </div>



    <div class="container__cards clearfix">
      <section class="card__footer">
        <p class="footer__card__text"><strong><?php bloginfo ('name'); ?></strong>
          <br>
          <br>
          <?php echo get_theme_mod('footer-address', esc_html__('Via Mario Rossi, 10', 'easyblue')); ?>
          <br>
          <?php echo get_theme_mod('footer-postal_code', esc_html__('CAP 12345', 'easyblue')); ?>
          <br>
          <?php echo get_theme_mod('footer-city', esc_html__('Milan (ITALY)', 'easyblue')); ?>
          <br>
          <?php echo get_theme_mod('footer-vat', esc_html__('P.IVA 1234567890', 'easyblue')); ?>
          <br>
          <strong><?php echo get_theme_mod('footer-mail-title', esc_html__('E-Mail:', 'easyblue')); ?></strong>
          <br>
          <?php echo get_theme_mod('footer-mail', esc_html__('info@example.com', 'easyblue')); ?><p/>
        </section>

      <section class="card__footer">
        <a href="<?php echo get_theme_mod('footer-privacy', esc_url('#'));?>" class="privacy-policy white"><?php esc_html_e('Privacy Policy','easyblue'); ?></a>
        <br>
        <a href="<?php echo get_theme_mod('footer-cookie', esc_url('#'));?>" class="cokie-policy white"><?php esc_html_e('Cookie Policy','easyblue'); ?></a>
      </section>

      <section class="card__footer">
        <p class="footer__card__text"><?php echo get_theme_mod('footer-follow', esc_html__('Follow us:', 'easyblue')); ?></p>
        <ul>
          <li class="footer__social"><a href="<?php echo get_theme_mod('link-2', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-2', esc_html__('fa-facebook-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
          <li class="footer__social"><a href="<?php echo get_theme_mod('link-1', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-1', esc_html__('fa-linkedin-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
          <li class="footer__social"><a href="<?php echo get_theme_mod('link-3', esc_url('#'));?>"><i class="fa <?php echo get_theme_mod('icon-3', esc_html__('fa-twitter-square', 'easyblue'));?> fa-lg" aria-hidden="true"></i></a></li>
        </ul>


      </section>
    </div><!-- chiusura container cards-->
  </div><!-- chiusura container footer blu -->
  <div class="footer__end clearfix">
    <p class="footer__left__text"><?php esc_html_e('Copyright &copy; ','easyblue'); ?> <?php the_date('Y'); ?> -  <?php bloginfo ('name'); ?> , <?php esc_html_e(' All Rights Reserved.','easyblue'); ?></p>
    <p class="footer__right__text"><?php esc_html_e('Powered by ','easyblue'); ?><a href="https://www.facebook.com/Gualtio"><?php esc_html_e(' GIULIO GUALTIERI', 'easyblue'); ?></a></p>
  </div>
</footer>


<?php wp_footer(); ?>
</body>
</html>
