jQuery(document).ready(function() {

		/* Upsells in customizer (Documentation link */
		jQuery('#customize-info').css({'border':'none'})

	  jQuery('#customize-info .preview-notice').append('<a style="background:#058ac3;color:#fff;padding:0px 10px;margin-top:10px;display:inline-block;font-size:10px;text-transform:uppercase;text-decoration:none;" href="https://github.com/Gualtio/wordpress-themes" target="_blank" class="view-pro-version">View the documentation</a>');

});
