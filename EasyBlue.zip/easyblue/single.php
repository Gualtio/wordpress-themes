<?php get_header(); ?>

<div class="container__body clearfix">



      <!-- THE LOOP -->
      <?php if (have_posts()) : while (have_posts()) : the_post();?>

        <!-- BODY (change) -->
        <article class="content" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <h1 class="content__title"><?php the_title(); ?></h1>
          <p class="card__date"><i class="fa fa-clock-o"></i> <?php the_time('j M Y') ?><span class="card__span"> | </span> <span class="card__category"><?php the_category(', ') ?></span></p>
          <?php the_post_thumbnail('easyblue_single', array('class' => 'img-index','alt' => get_the_title())); ?>
          <div class="single__p"><?php the_content(); ?></div>
          <?php $post_tags = wp_get_post_tags($post->ID); if(!empty($post_tags)) {?>
      						<p class="cont-tag"><span class="tag"> <i class="fa fa-tag"></i> <?php the_tags('', ', ', ''); ?> </span></p>
      					<?php } ?>
        </article> <!-- fine content -->


    <?php endwhile; else :  ?>

      <strong><?php esc_html_e('Ooops, nothing found!','easyblue'); ?></strong>

    <?php endif; ?>



    <!-- SIDEBAR -->
    <aside class="sidebar">

      <?php get_sidebar(); ?>

    </aside>



			<div class="comments">
				<?php comments_template(); ?>
			</div>





</div><!-- fine container body -->

<!-- SIDEBAR MOBILE-->
<aside class="sidebar--mobile">

  <?php get_sidebar('mobile'); ?>

</aside>


<?php get_footer(); ?>
