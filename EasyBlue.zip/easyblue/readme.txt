Thank you for downloading EasyBlue Theme!


Features:

Widgets
has one sidebar on the right


There is a front page and 2 page template for 'services' and 'contacts'
Menu on top and on the footer


All the code is write by hand..no frameworks!





License:



EasyBlue WordPress theme, Copyright (C) 2017 Gualtieri Giulio. WordPress theme is licensed under the GPL.



Font Awesome - http://fontawesome.io
License: Distributed under the terms of the SIL OFL License 1.1 (fonts), MIT License (code), and CC BY 3.0 License (documentation)
Copyright: Font Awesome, http://fontawesome.io

jQuery

License: Distributed under MIT license (MIT)
Copyright: Copyright 2010, 2013 jQuery Foundation

https://jquery.org/license/

All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/



Adopting Wlow Theme (Theme Re-Distribution):



It's GPL so yes you can base your Themes from EasyBlue.

Please note that if you do that, the GPLv3 License needs to stay
as well as all copyright notices included in all parts of
this Theme.
