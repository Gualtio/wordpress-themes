<?php
/**
 * Contains methods for customizing the theme customization screen.
 *
 * @link http://codex.wordpress.org/Theme_Customization_API
 */
 ?>


<?php

/* Customization API */

function easyblue_customizer_register( $wp_customize ) {
//Section: Header
$wp_customize->add_section( 'easyblue-header-section' , array(
	'title'      => esc_html__('Header', 'easyblue'),
	'description'=> esc_html__('Customize the header', 'easyblue')
) );

//setting for change an image
$wp_customize->add_setting( 'header-image', array(
	'default' => get_template_directory_uri() . '/img/header.jpg',
  'sanitize_callback' => 'easyblue_sanitize_image_url'
));

$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'header-image-control', array(
	'label'      => esc_html__('Visual background image', 'easyblue'),
	'section'    => 'easyblue-header-section',
	'settings'   => 'header-image'

) ) ); /* funziona con es: <img src="<?php echo wp_get_attachment_url(get_theme_mod('header-image')) ?> "> */


		//setting for big title
		$wp_customize->add_setting( 'header-title' , array(
			'default'   => esc_html__('IMPRESSIVE TITLE', 'easyblue'),
      'sanitize_callback' => 'sanitize_text_field'
	) );

		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header-control', array(
			'label'      => esc_html__('Big Title', 'easyblue'),
			'section'    => 'easyblue-header-section',
			'settings'   => 'header-title'  /* si usano con <?php echo get_theme_mod('setting_name'); ?>*/
	) ) );
	//setting for paragraph
	$wp_customize->add_setting( 'header-text' , array(
		'default'   => esc_html__('Some impressive words, that can focus your attention on the mean of our mission. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header-text-control', array(
		'label'      => esc_html__('Subtitle', 'easyblue'),
		'section'    => 'easyblue-header-section',
		'settings'   => 'header-text',
		'type'       => 'textarea' //per dire che non è una single line text ma una rea di testo
) ) );

//setting for button text
$wp_customize->add_setting( 'header-button-text' , array(
	'default'   => esc_html__('CALL TO ACTION', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header-button-text-control', array(
	'label'      => esc_html__('Insert your CALL TO ACTION', 'easyblue'),
	'section'    => 'easyblue-header-section',
	'settings'   => 'header-button-text'
) ) );

//setting for link url
$wp_customize->add_setting( 'header-button-url' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header-button-url-control', array(
	'label'      => esc_html__('Button absolute URL', 'easyblue'),
	'section'    => 'easyblue-header-section',
	'settings'   => 'header-button-url',
	'type'       => 'textarea' //se inserisco in un href un url assoluto ho il link
) ) );


/*------------------------------------------- BODY ----------------------------------------------------------*/


/* HOME PAGE *******************************************************/
$wp_customize->add_panel( 'easyblue-body-panel' , array(
	'title'      => esc_html__('Body', 'easyblue'),
	'description'=> esc_html__('You can customize the body of the Home Page, Services page and the Contacts page', 'easyblue')

) );

//Section: Body
$wp_customize->add_section( 'easyblue-body-section' , array(
	'title'      => esc_html__('Home Page', 'easyblue'),
	'description'=> esc_html__('Customize the Home Page', 'easyblue'),
	'panel' => 'easyblue-body-panel'
) );

//setting for Company name
$wp_customize->add_setting( 'body-company-text' , array(
	'default'   => esc_html__('COMPANY NAME', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-company_name-control', array(
	'label'      => esc_html__('Insert your Company Name', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-company-text'
) ) );

//setting for change body image
$wp_customize->add_setting( 'body-image', array(
	'default' => get_template_directory_uri() . '/img/body_1.jpeg',
  'sanitize_callback' => 'easyblue_sanitize_image_url'
));


$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'header-image_body-control', array(
	'label'      => esc_html__('Body image', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-image'

) ) ); /* funziona con es: <img src="<?php echo wp_get_attachment_url(get_theme_mod('setting-name')) ?> "> */

//setting for body subtitle 1
$wp_customize->add_setting( 'body-subtitle1-text' , array(
	'default'   => esc_html__('OUR STORY', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-subtitle1-control', array(
	'label'      => esc_html__('Text for the first subtitle', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-subtitle1-text'
) ) );

//setting for body paragraph 1
$wp_customize->add_setting( 'body-text1' , array(
	'default'   => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-text1-control', array(
	'label'      => esc_html__('Text for the first paragraph', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-text1',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//setting for body subtitle 2
$wp_customize->add_setting( 'body-subtitle_2-text' , array(
	'default'   => esc_html__('OUR MISSION', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-subtitle_2-control', array(
	'label'      => esc_html__('Text for the first subtitle', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-subtitle_2-text'
) ) );

//setting for body paragraph 2
$wp_customize->add_setting( 'body-text2' , array(
	'default'   => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-text2-control', array(
	'label'      => esc_html__('Text for the second paragraph', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-text2',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//setting for body link text
$wp_customize->add_setting( 'body-link-text' , array(
	'default'   => esc_html__('Find out our services >', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-subtitle2-control', array(
	'label'      => esc_html__('Text for the internal link text', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-link-text'
) ) );

//setting for body link (internal)
$wp_customize->add_setting( 'body-link', array(
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-link-control', array(
	'label'      => esc_html__('Internal Pages link', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-link',
	'type'       => 'dropdown-pages' //collega a una pagina interna del sito
) ) );

//card post title
$wp_customize->add_setting( 'body-card_title-text' , array(
	'default'   => esc_html__('NEWS', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'body-cards-control', array(
	'label'      => esc_html__('Text for the cards title', 'easyblue'),
	'section'    => 'easyblue-body-section',
	'settings'   => 'body-card_title-text'
) ) );

//setting for display yes or no NEWS section (3 posts)
	$wp_customize->add_setting( 'front-news' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'front-news-control', array(
		'label'      => esc_html__('Display the news section? (Maybe you want to display this section when you have at least 3 posts.)', 'easyblue'),
		'section'    => 'easyblue-body-section',
		'settings'   => 'front-news',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );
/* FINE HOME PAGE *******************************************************/




/* SERVICES PAGE *******************************************************/
//Section: Services
$wp_customize->add_section( 'easyblue-services-section' , array(
	'title'      => esc_html__('Services page', 'easyblue'),
	'description'=> esc_html__('Customize the Services Page', 'easyblue'),
	'panel' => 'easyblue-body-panel'
) );

//setting for change body image
$wp_customize->add_setting( 'services-image', array(
	'default' => get_template_directory_uri() . '/img/body_2.jpeg',
  'sanitize_callback' => 'easyblue_sanitize_image_url'
));


$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'services-image-control', array(
	'label'      => esc_html__('Image', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-image'

) ) ); /* funziona con es: <img src="<?php echo wp_get_attachment_url(get_theme_mod('setting-name')) ?> "> */

//subtitle
$wp_customize->add_setting( 'services-subtitle' , array(
	'default'   => esc_html__('OUR SERVICES', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-subtitle-control', array(
	'label'      => esc_html__('Subtitle', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-subtitle'
) ) );

//paragraph
$wp_customize->add_setting( 'services-text' , array(
	'default'   => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-text-control', array(
	'label'      => esc_html__('Text for the paragraph', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-text',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//service1
$wp_customize->add_setting( 'services-service1' , array(
	'default'   => esc_html__('Service number 1', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-list1-control', array(
	'label'      => esc_html__('Name of service 1', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-service1'
) ) );

//setting for display yes or no
	$wp_customize->add_setting( 'services-display1' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-display1-control', array(
		'label'      => esc_html__('Display this item?', 'easyblue'),
		'section'    => 'easyblue-services-section',
		'settings'   => 'services-display1',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );

//service2
$wp_customize->add_setting( 'services-service2' , array(
	'default'   => esc_html__('Service number 2', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-list2-control', array(
	'label'      => esc_html__('Name of service 2', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-service2'
) ) );

//setting for display yes or no
	$wp_customize->add_setting( 'services-display2' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-display2-control', array(
		'label'      => esc_html__('Display this item?', 'easyblue'),
		'section'    => 'easyblue-services-section',
		'settings'   => 'services-display2',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );

//service3
$wp_customize->add_setting( 'services-service3' , array(
	'default'   => esc_html__('Service number 3', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-list3-control', array(
	'label'      => esc_html__('Name of service 3', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-service3'
) ) );

//setting for display yes or no
	$wp_customize->add_setting( 'services-display3' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-display3-control', array(
		'label'      => esc_html__('Display this item?', 'easyblue'),
		'section'    => 'easyblue-services-section',
		'settings'   => 'services-display3',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );

//service4
$wp_customize->add_setting( 'services-service4' , array(
	'default'   => esc_html__('Service number 4', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-list4-control', array(
	'label'      => esc_html__('Name of service 4', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-service4'
) ) );

//setting for display yes or no
	$wp_customize->add_setting( 'services-display4' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-display4-control', array(
		'label'      => esc_html__('Display this item?', 'easyblue'),
		'section'    => 'easyblue-services-section',
		'settings'   => 'services-display4',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );

//link
$wp_customize->add_setting( 'services-link' , array(
	'default'   => esc_html__('Contact us for more info >', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-link-control', array(
	'label'      => esc_html__('Link text', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-link'
) ) );

//link internal
$wp_customize->add_setting( 'services-url', array(
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-url-control', array(
	'label'      => esc_html__('Link absolute URL', 'easyblue'),
	'section'    => 'easyblue-services-section',
	'settings'   => 'services-url',
	'type' => 'dropdown-pages'
) ) );

//setting for display yes or no NEWS section (3 posts)
	$wp_customize->add_setting( 'services-news' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'services-news-control', array(
		'label'      => esc_html__('Display the news section? (Maybe you want to display this section when you have at least 3 posts.)', 'easyblue'),
		'section'    => 'easyblue-services-section',
		'settings'   => 'services-news',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );





/* CONTACTS PAGE *******************************************************/
//Section: contacts
$wp_customize->add_section( 'easyblue-contacts-section' , array(
	'title'      => esc_html__('Contacts page', 'easyblue'),
	'description'=> esc_html__('Customize the Contacts Page', 'easyblue'),
	'panel' => 'easyblue-body-panel'
) );

//setting for change body image
$wp_customize->add_setting( 'contacts-image', array(
	'default' => get_template_directory_uri() . '/img/body_3.jpg',
  'sanitize_callback' => 'easyblue_sanitize_image_url'
));


$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'contacts-image-control', array(
	'label'      => esc_html__('Image', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-image'

) ) ); /* funziona con es: <img src="<?php echo wp_get_attachment_url(get_theme_mod('setting-name')) ?> "> */

//subtitle
$wp_customize->add_setting( 'contacts-subtitle' , array(
	'default'   => esc_html__('CONTACT US', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-subtitle-control', array(
	'label'      => esc_html__('Subtitle', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-subtitle'
) ) );

//paragraph
$wp_customize->add_setting( 'contacts-text' , array(
	'default'   => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-text-control', array(
	'label'      => esc_html__('Text for the paragraph', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-text',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//E-MAIL
$wp_customize->add_setting( 'contacts-mail' , array(
	'default'   => esc_html__('E-MAIL', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-mail-control', array(
	'label'      => esc_html__('E-Mail title ', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-mail'
) ) );

//mail text
$wp_customize->add_setting( 'contacts-mail-text' , array(
	'default'   => esc_html__('info@example.com', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-mail_text-control', array(
	'label'      => esc_html__('Insert the E-Mail', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-mail-text',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//Phone
$wp_customize->add_setting( 'contacts-phone' , array(
	'default'   => esc_html__('PHONE NUMBER', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-phone-control', array(
	'label'      => esc_html__('Phone number title ', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-phone'
) ) );

//number
$wp_customize->add_setting( 'contacts-phone-text' , array(
	'default'   => esc_html__('+39 123.456.789', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-phone_text-control', array(
	'label'      => esc_html__('Insert the Phone number', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-phone-text',
	'type'       => 'textarea' //per dire che non è una single line text ma una area di testo
) ) );

//Social title
$wp_customize->add_setting( 'contacts-social' , array(
	'default'   => esc_html__('SOCIAL NETWORKS', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-social-control', array(
	'label'      => esc_html__('Social Networks title ', 'easyblue'),
	'section'    => 'easyblue-contacts-section',
	'settings'   => 'contacts-social'
) ) );

/* ---------------------------NEWS ----------------*/
//Section: News
$wp_customize->add_section( 'easyblue-news-section' , array(
	'title'      => esc_html__('News section', 'easyblue'),
	'description'=> esc_html__('Customize the News section', 'easyblue'),
	'panel' => 'easyblue-body-panel'
) );

//news title
$wp_customize->add_setting( 'news-title' , array(
	'default'   => esc_html__('NEWS', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'news-title-control', array(
	'label'      => esc_html__('Title', 'easyblue'),
	'section'    => 'easyblue-news-section',
	'settings'   => 'news-title'
) ) );

//setting for display yes or no NEWS section (3 posts)
	$wp_customize->add_setting( 'contacts-news' , array(
		'default'   => esc_html__('Yes', 'easyblue'),
    'sanitize_callback' => 'sanitize_text_field'
) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'contacts-news-control', array(
		'label'      => esc_html__('Display the news section? (Maybe you want to display this section when you have at least 3 posts.)', 'easyblue'),
		'section'    => 'easyblue-contacts-section',
		'settings'   => 'contacts-news',
		'type'			 => 'select',
		'choices'		 => array(esc_html__('No', 'easyblue') => esc_html__('No', 'easyblue'), esc_html__('Yes', 'easyblue') => esc_html__('Yes', 'easyblue')  /* si usa con un if attorno al div interessato <?php if (get_theme_mod('header-display') == "Yes") { ?> e chiudo alla fine del div <?php } ?> */

) ) ) );




/*------------------------------------------- FOOTER ----------------------------------------------------------*/

//Section: Footer
$wp_customize->add_section( 'easyblue-footer-section' , array(
	'title'      => esc_html__('Footer', 'easyblue'),
	'description'=> esc_html__('Customize the footer', 'easyblue')
) );

//Address
$wp_customize->add_setting( 'footer-address' , array(
	'default'   => esc_html__('Via Mario Rossi, 10', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-address-control', array(
	'label'      => esc_html__('Address and number', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-address'
) ) );

//postal code
$wp_customize->add_setting( 'footer-postal_code' , array(
	'default'   => esc_html__('CAP 12345', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-cap-control', array(
	'label'      => esc_html__('Postal Code', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-postal_code'
) ) );

//city (state)
$wp_customize->add_setting( 'footer-city' , array(
	'default'   => esc_html__('Milan (ITALY)', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-city-control', array(
	'label'      => esc_html__('City (STATE)', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-city'
) ) );

//VAT number
$wp_customize->add_setting( 'footer-vat' , array(
	'default'   => esc_html__('P.IVA 1234567890', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-vat-control', array(
	'label'      => esc_html__('VAT Number', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-vat'
) ) );

//Mail-title
$wp_customize->add_setting( 'footer-mail-title' , array(
	'default'   => esc_html__('E-Mail:', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-mail_title-control', array(
	'label'      => esc_html__('E-Mail title', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-mail-title'
) ) );

//Mail
$wp_customize->add_setting( 'footer-mail' , array(
	'default'   => esc_html__('info@example.com', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-mail-control', array(
	'label'      => esc_html__('E-Mail address', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-mail'
) ) );

//Privacy Policy
$wp_customize->add_setting( 'footer-privacy' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-privacy-control', array(
	'label'      => esc_html__('Privacy Policy link', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-privacy'
) ) );

//Cookie Policy
$wp_customize->add_setting( 'footer-cookie' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-cookie-control', array(
	'label'      => esc_html__('Cookie Policy link', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-cookie'
) ) );

//Follow us
$wp_customize->add_setting( 'footer-follow' , array(
	'default'   => esc_html__('Follow us:', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'footer-follow-control', array(
	'label'      => esc_html__('Follow us title', 'easyblue'),
	'section'    => 'easyblue-footer-section',
	'settings'   => 'footer-follow'
) ) );



/* -------------------------- ICONS ----------------------------------------------------------------------- */

//Section: Footer
$wp_customize->add_section( 'easyblue-icons-section' , array(
	'title'      => esc_html__('Icons', 'easyblue'),
	'description'=> esc_html__('Select the icons and links. Visit http://fontawesome.io/icons/ for the icons name full list.', 'easyblue')
) );

//icon 1
$wp_customize->add_setting( 'icon-1' , array(
	'default'   => esc_html__('fa-linkedin-square', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'icon_1-control', array(
	'label'      => esc_html__('Icon 1', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'icon-1'
) ) );

//link 1
$wp_customize->add_setting( 'link-1' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'link_1-control', array(
	'label'      => esc_html__('Link 1 (absolute url)', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'link-1'
) ) );

//icon 2
$wp_customize->add_setting( 'icon-2' , array(
	'default'   => esc_html__('fa-facebook-square', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'icon_2-control', array(
	'label'      => esc_html__('Icon 2', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'icon-2'
) ) );

//link 2
$wp_customize->add_setting( 'link-2' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'link_2-control', array(
	'label'      => esc_html__('Link 2 (absolute url)', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'link-2'
) ) );

//icon 2
$wp_customize->add_setting( 'icon-3' , array(
	'default'   => esc_html__('fa-twitter-square', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'icon_3-control', array(
	'label'      => esc_html__('Icon 3', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'icon-3'
) ) );

//link 2
$wp_customize->add_setting( 'link-3' , array(
	'default'   => esc_html__('#', 'easyblue'),
  'sanitize_callback' => 'sanitize_text_field'
) );

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'link_3-control', array(
	'label'      => esc_html__('Link 3 (absolute url)', 'easyblue'),
	'section'    => 'easyblue-icons-section',
	'settings'   => 'link-3'
) ) );




/* -------------------------- COLORS ----------------------------------------------------------------------- */

//setting for change colors
$wp_customize->add_section( 'easyblue-colors-section' , array(
	'title'      => esc_html__('Colors', 'easyblue'),
	'description'=> esc_html__('Change theme colors', 'easyblue')
) );

/* theme-color-1 */
$wp_customize->add_setting( 'theme-color-1', array(
	'default' => '#046ABF',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color1-control', array(
	'label'      => esc_html__('Main color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-1'
) ) );

/* theme-color-2 */
$wp_customize->add_setting( 'theme-color-2', array(
	'default' => '#058AC3',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color2-control', array(
	'label'      => esc_html__('Secondary Color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-2'
) ) );

/* theme-color-3 */
$wp_customize->add_setting( 'theme-color-3', array(
	'default' => '#FFFFFF',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color3-control', array(
	'label'      => esc_html__('Third Color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-3'
) ) );

/* theme-color-4 */
$wp_customize->add_setting( 'theme-color-4', array(
	'default' => '#00EC67',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color4-control', array(
	'label'      => esc_html__('Post Category Link', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-4'
) ) );

/* theme-color-5 */
$wp_customize->add_setting( 'theme-color-5', array(
	'default' => '#35C2FF',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color5-control', array(
	'label'      => esc_html__('Menu hover color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-5'
) ) );

/* theme-color-6 */
$wp_customize->add_setting( 'theme-color-6', array(
	'default' => '#35C2FF',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color6-control', array(
	'label'      => esc_html__('Social Icons color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-6'
) ) );

/* theme-color-4 */
$wp_customize->add_setting( 'theme-color-7', array(
	'default' => '#00EC67',
	'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme-color7-control', array(
	'label'      => esc_html__('Social Icons hover color', 'easyblue'),
	'section'    => 'easyblue-colors-section',
	'settings'   => 'theme-color-7'
) ) );



}


add_action( 'customize_register', 'easyblue_customizer_register' ); // richima la funzione di prima


//Output Customize css
function easyblue_customizer_css() { ?>

	<style type="text/css">

		/* theme-color-1*/
		.header__top, .header__menu {background-color: <?php echo get_theme_mod('theme-color-1', '#046ABF'); ?>; }
		.content {border-top: 4px solid <?php echo get_theme_mod('theme-color-1', '#046ABF'); ?>;border-bottom: 4px solid <?php echo get_theme_mod('theme-color-1', '#046ABF'); ?>;}
		.cont-tag span {color: <?php echo get_theme_mod('theme-color-1', '#046ABF'); ?>;}


		/* theme-color-2 */
		.header__title, .content__subtitle, .content__link, .card__date, .services__list__item,
		 		.contacts__title, .content__title, .moretag, .fn, .comment-reply-link, .comment-reply-title, .url {color:<?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.header__subtitle {border-left: 4px solid <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>; }
		.header__call, .sidebar, .footer, .card__label {background: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>; }
		.card {border-bottom: 0.2vw	solid <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.card__title a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.footer__right__text a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.news {border-bottom: 2px solid <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.pagination a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.news__title a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.comment-meta a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.comment-reply-title a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.form-submit input{background: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
		.comments_rss a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
    .logged-in-as a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
    .single__p a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}
    .card__date a {color: <?php echo get_theme_mod('theme-color-2', '#058AC3'); ?>;}


		/* theme-color-3 */
		.header__logo, .header__logo, .header__subtitle, .header__call__link, .widget,
		 		.card__label, .footer__menu__theme, .footer__menu__item, .card__footer, .footer__left__text,
			 	.footer__right__text {color: <?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>; }
		.menu-item a {color:<?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>; }
		.widget a {border-bottom: 1px solid <?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>; }
		.widget a {color: <?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>; }
		#wp-calendar tbody td {border: 1px solid <?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>; }
	  .footer__menu {border-bottom: 2px solid	<?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>;}
		.card__footer {border-bottom: 0.2vw	solid	<?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?>;}
		.white {color:<?php echo get_theme_mod('theme-color-3', '#FFFFFF'); ?> !important;}

		/* theme color - 4 post category link and hover icons */
		.card__category a {color: <?php echo get_theme_mod('theme-color-4', '#00EC67'); ?>;}
		.card__footer a:hover {color: <?php echo get_theme_mod('theme-color-4', '#00EC67'); ?>;}

		/* menu hover color */
		.menu-item a:hover {color: <?php echo get_theme_mod('theme-color-5', '#35C2FF'); ?>;}

		/* social icons color */
		.header__social a {color: <?php echo get_theme_mod('theme-color-6', '#35C2FF'); ?>}
		.card__footer a {color: <?php echo get_theme_mod('theme-color-6', '#35C2FF'); ?>}


		/* social icons hover color */
		.header__social a:hover {color: <?php echo get_theme_mod('theme-color-7', '#00EC67'); ?>;}
		.card__footer a:hover {color: <?php echo get_theme_mod('theme-color-7', '#00EC67'); ?>;}
		.tag a {color: <?php echo get_theme_mod('theme-color-7', '#00EC67'); ?>;}

	</style>

<?php }

add_action('wp_head', 'easyblue_customizer_css');
?>

<?php

/**
 * Sanitizes the incoming input and returns it prior to serialization.
 *
 * @param      string    $input    The string to sanitize
 * @return     string              The sanitized string
 * @package    fb
 * @since      0.5.0
 * @version    1.0.2
 */
function easyblue_sanitize_image_url( $input ) {
	return esc_url_raw( $input  );
} // end easyblue_sanitize_input


/* Customizer script */
function easyblue_registers() {

	wp_enqueue_script( 'easyblue_customizer_script', get_template_directory_uri() . '/js/easyblue-customizer.js', array("jquery"), '20120206', true  );

}
add_action( 'customize_controls_enqueue_scripts', 'easyblue_registers' );

 ?>
