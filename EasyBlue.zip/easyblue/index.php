<?php
/**
 * Theme: Wlow
 *
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * Also it's used to display search results, category page, tag page and date page.
 *
 * @package easyblue
 */
 ?>

<?php get_header(); ?>

<div class="container__body clearfix">



  <!-- BODY (change) -->
  <section class="content--news">
    <h2 class="content__title"><?php echo get_theme_mod('news-title', esc_html__('NEWS', 'easyblue')); ?></h2>
    <div class="container__news clearfix">

      <!-- THE LOOP -->
      <?php if (have_posts()) : while (have_posts()) : the_post();?>

      <article class="news" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <h2 class="news__title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
        <p class="card__date"><i class="fa fa-clock-o"></i><a href="<?php the_permalink();?>"> <?php the_time('j M Y') ?></a><span class="card__span"> | </span> <span class="card__category"><?php the_category(', ') ?></span></p>
        <a href="<?php the_permalink();?>">
          <?php the_post_thumbnail('easyblue_single', array('class' => 'img-news','alt' => get_the_title())); ?>
        </a>
        <div class="news__p"><?php the_excerpt(); ?></div>
      </article>

    <?php endwhile; ?>

      <?php get_template_part('inc/pagination'); ?>

    <?php else :  ?>

      <strong><?php esc_html_e('Ooops, nothing found!','easyblue'); ?></strong>

    <?php endif; ?>


  </section> <!-- fine content -->

  <!-- SIDEBAR -->
  <aside class="sidebar">

    <?php get_sidebar(); ?>

  </aside>


</div><!-- fine container body -->


<!-- SIDEBAR MOBILE-->
<aside class="sidebar--mobile">

  <?php get_sidebar('mobile'); ?>

</aside>




<?php get_footer(); ?>
