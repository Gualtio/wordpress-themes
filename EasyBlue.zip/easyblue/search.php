<?php get_header(); ?>

<div class="container__body clearfix">



  <!-- BODY (change) -->
  <section class="content--news">
    <h2 class="content__title"><?php esc_html_e('Search results for: ','easyblue'); ?> <strong><i><?php echo $s; ?></i></strong></h2>
    <div class="container__news clearfix">

      <!-- THE LOOP -->
      <?php if (have_posts()) : while (have_posts()) : the_post();?>

      <article class="news" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <h2 class="news__title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
        <p class="card__date"><i class="fa fa-clock-o"></i> <?php the_time('j M Y') ?><span class="card__span"> | </span> <span class="card__category"><?php the_category(', ') ?></span></p>
        <a href="<?php the_permalink();?>">
          <?php the_post_thumbnail('easyblue_single', array('class' => 'img-index','alt' => get_the_title())); ?>
        </a>
        <div class="news__p"><?php the_excerpt(); ?></div>
      </article>

    <?php endwhile; ?>

      <?php get_template_part('inc/pagination'); ?>

    <?php else :  ?>

      <strong><?php esc_html_e('Ooops, nothing found!','easyblue'); ?></strong>

    <?php endif; ?>


  </section> <!-- fine content -->

  <!-- SIDEBAR -->
  <aside class="sidebar">

    <?php get_sidebar(); ?>

  </aside>


</div><!-- fine container body -->

<!-- SIDEBAR MOBILE-->
<aside class="sidebar--mobile">

  <?php get_sidebar('mobile'); ?>

</aside>


<?php get_footer(); ?>
