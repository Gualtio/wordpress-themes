<?php
/**
 * Theme: EasyBlue
 *
 * Theme Functions, includes, etc.
 *
 * @package easyblue
 */


/*  Theme setup
/* ------------------------------------ */
if ( ! function_exists( 'easyblue_setup' ) ) {

	function easyblue_setup() {

		add_theme_support( "title-tag" );

		// Enable automatic feed links
		add_theme_support( 'automatic-feed-links' );

		// Enable featured image
		add_theme_support( 'post-thumbnails' );

		// Thumbnail sizes
		add_image_size( 'easyblue_big', 1400, 1928, true ); 	//(cropped)
		add_image_size( 'easyblue_single', 800, 9999, true ); 	//(cropped)

		// Custom menu areas
			//header
			register_nav_menus( array(
				'header' => esc_html__( 'Header', 'easyblue' ),
			) );

			//footer
			register_nav_menus( array(
				'footer' => esc_html__( 'Footer', 'easyblue' ),
			) );

		// Load theme languages
		load_theme_textdomain( 'easyblue', get_template_directory().'/languages' );

	}

}
add_action( 'after_setup_theme', 'easyblue_setup' );



/*  Include Styles and script
/* ------------------------------------ */
if ( ! function_exists( 'easyblue_styles_scripts' ) ) {

	function easyblue_style_scripts() {

		//wp_enqueue_script('jquery');
		wp_enqueue_script( 'easyblue-scripts', get_template_directory_uri() . '/js/easyblue-customizer.js', array( 'jquery' ),'', true );

		wp_enqueue_style( 'easyblue-ralewayopen','//fonts.googleapis.com/css?family=Open+Sans|Raleway:300,400,700,900');

		wp_enqueue_style( 'easyblue-normalize', 'https://cdnjs.cloudflare.com/ajax/libs/normalize/7.0.0/normalize.min.css');

		wp_enqueue_style( 'easyblue', get_template_directory_uri().'/style.css');

		wp_enqueue_style( 'easyblue-fontawesome', get_template_directory_uri().'/css/font-awesome.css');

	}

}
add_action( 'wp_enqueue_scripts', 'easyblue_style_scripts' );


/*  Register sidebars
/* ------------------------------------ */
if ( ! function_exists( 'easyblue_sidebars') ) {

	function easyblue_sidebars()	{
		register_sidebar(array( 'name' => esc_html__( 'Primary', 'easyblue' ),'id' => 'primary','description' => esc_html__( 'Normal full width sidebar.', 'easyblue' ), 'before_widget' => '<div id="%1$s" class="widget %2$s">','after_widget' => '</div>','before_title' => '<h3>','after_title' => '</h3>'));

	}

}
add_action( 'widgets_init', 'easyblue_sidebars');

if ( ! function_exists( 'easyblue_sidebars_mobile') ) {

	function easyblue_sidebars_mobile()	{
		register_sidebar(array( 'name' => esc_html__( 'Mobile', 'easyblue' ),'id' => 'mobile','description' => esc_html__( 'Normal full width sidebar (mobile).', 'easyblue' ), 'before_widget' => '<div id="%1$s" class="widget %2$s">','after_widget' => '</div>','before_title' => '<h3>','after_title' => '</h3>'));

	}

}
add_action( 'widgets_init', 'easyblue_sidebars_mobile');


/* Default top bar menu
/* ------------------------------------ */
function easyblue_top_bar_menu_cb() {
	if ( current_user_can( 'manage_options' ) ) {
		echo '<ul><li><a href="'. esc_url(admin_url( 'nav-menus.php' )) .'">'. esc_html__('Add a Menu','easyblue') .'</a></li></ul>';
	}
};


/* custom excerpt lenght */
/*-----------------------------------*/

function custom_excerpt_length( $length ) {
	return 70;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );


// Replaces the excerpt "Read More" text by a link
function new_excerpt_more($more) {
       global $post;
	return '<a class="moretag" href="'. get_permalink($post->ID) . '"> <strong>[More]</strong></a>';
}
add_filter('excerpt_more', 'new_excerpt_more');


/* Customizer API */

require get_template_directory() . '/inc/customizer.php';   // customizer api

/* ------------------------------------------------------------------------- *
 *  Base functionality
/* ------------------------------------------------------------------------- */


	// Content width
	if ( !isset( $content_width ) ) { $content_width = 1400; }




	/* ------------------------------------------------------------------------- *
 *  General
/* ------------------------------------------------------------------------- */

	/*  Disable Gallery Inline Style
	/* ------------------------------------ */
	add_filter( 'use_default_gallery_style', '__return_false' );

	/*  Oembed Responsive
	/* ------------------------------------ */
	add_filter( 'embed_oembed_html', 'easyblue_oembed_filter', 10, 4 ) ;

	function easyblue_oembed_filter($html, $url, $attr, $post_ID) {
		$return = '<figure class="video-container">'.$html.'</figure>';
		return $return;
	}

	/*  Enable hr button tiny MCE
	/* ------------------------------------ */
	function easyblue_enable_more_buttons($buttons) {
	  $buttons[] = 'hr';
	  return $buttons;
	}
	add_filter("mce_buttons", "easyblue_enable_more_buttons");





	/*  Add Excerpt on Pages for Seo description
	/* ------------------------------------ */
	add_action( 'init', 'easyblue_add_excerpts_to_pages' );
	function easyblue_add_excerpts_to_pages() {
	     add_post_type_support( 'page', 'excerpt' );
	}

	/* Add images to RSS Feed
	/* ------------------------------------ */
	function easyblue_rss_post_thumbnail($content) {

		global $post;

		if(has_post_thumbnail($post->ID)) {

			$content = '<p>' . get_the_post_thumbnail($post->ID, 'single') . '</p>' . get_the_content();
			$content = preg_replace("/\[caption.*\[\/caption\]/", '',$content);

		}

		return $content;
	}
	add_filter('the_excerpt_rss', 'easyblue_rss_post_thumbnail');
	add_filter('the_content_feed', 'easyblue_rss_post_thumbnail');

?>
