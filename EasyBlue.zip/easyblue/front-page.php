<?php get_header(); ?>

<div class="container__body clearfix">

  <!-- BODY (change) -->
  <section class="content">
    <h2 class="content__title"><?php echo get_theme_mod('body-company-text', esc_html__('COMPANY NAME', 'easyblue')); ?></h2>
    <img class="content__img" src="<?php echo get_theme_mod('body-image', get_template_directory_uri() . '/img/body_1.jpeg') ?>">
    <h3 class="content__subtitle"><?php echo get_theme_mod('body-subtitle1-text', esc_html__('OUR STORY', 'easyblue')); ?></h3>
    <p class="content__subtitle__p"><?php echo get_theme_mod('body-text1', esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue')) ?></p>
    <h3 class="content__subtitle"><?php echo get_theme_mod('body-subtitle_2-text', esc_html__('OUR MISSION', 'easyblue')); ?></h3>
    <p class="content__subtitle__p"><?php echo get_theme_mod('body-text2', esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'easyblue')) ?></p>
    <a class="content__link" href="<?php echo get_permalink(get_theme_mod('body-link', esc_html__('#', 'easyblue'))); ?>"><?php echo get_theme_mod('body-link-text', esc_html__('Find out our services >', 'easyblue')) ?></a>
  </section> <!-- fine content -->

  <!-- SIDEBAR -->

  <aside class="sidebar">

    <?php get_sidebar(); ?>

  </aside>




  <?php if (get_theme_mod('front-news', esc_html__('Yes', 'easyblue')) == "Yes"); { ?>
  <!-- NEWS -->
  <div class="container__cards clearfix">


    <!-- Start latest post -->

    <?php $latest_post = get_posts( 'numberposts=3' ); // Defaults args fetch posts starting with the most recent ?>
    <?php foreach( $latest_post as $post ) : setup_postdata( $post ); ?>

      <article id="post-<?php the_ID(); ?>" class="card">
        <h3 class="card__label"><?php echo get_theme_mod('body-card_title-text', esc_html__('NEWS', 'easyblue')); ?></h3>

        <div class="card__img">
          <?php if ( has_post_thumbnail() ) : ?>
            <a href="<?php the_permalink();?>">
              <?php the_post_thumbnail('easyblue_single', array('class' => 'img-res','alt' => get_the_title())); ?>
            </a>
          <?php else : ?>
            <img class="dummy__img" src="<?php echo get_template_directory_uri(); ?>/img/dummy.jpeg">
          <?php endif; ?>
        </div>

        <h3 class="card__title"><a href="<?php the_permalink();?>"><?php the_title (); ?></a></h3>
        <p class="card__date"><i class="fa fa-clock-o"></i> <?php the_time('j M Y') ?> <span class="card__span"> | </span> <span class="card__category"><?php the_category(', '); ?></span></p>
        <div class="card__text"><?php the_excerpt(); ?></div>
      </article> <!--  fine card -->

    <?php endforeach; ?>
    <?php wp_reset_query(); ?>

    <!-- End latest post -->

  </div><!-- fine container cards --> <?php } ?>
</div><!-- fine container body -->

<!-- SIDEBAR MOBILE-->
<aside class="sidebar--mobile">

  <?php get_sidebar('mobile'); ?>

</aside>


<?php get_footer(); ?>
