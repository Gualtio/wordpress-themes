<?php
/**
 * Template for displaying 404 pages (Not Found)
 *
 * @package easyblue
 */

 ?>

<?php get_header(); ?>

<div class="container__body clearfix">



  <!-- BODY (change) -->
  <section class="content--news">
    <h2 class="content__title"><?php esc_html_e('Something goes wrong!','easyblue'); ?></h2>
    <div class="container__news clearfix">
      <h3 class="content__subtitle"><?php esc_html_e('Error 404','easyblue'); ?></h3>




  </section> <!-- end content -->

  <!-- SIDEBAR -->
  <aside class="sidebar">

    <?php get_sidebar(); ?>

  </aside>


</div><!-- end container body -->

<!-- SIDEBAR MOBILE-->
<aside class="sidebar--mobile">

  <?php get_sidebar('mobile'); ?>

</aside>


<?php get_footer(); ?>
